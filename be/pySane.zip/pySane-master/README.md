pySane
======

Python scanimage client with ssh support.
